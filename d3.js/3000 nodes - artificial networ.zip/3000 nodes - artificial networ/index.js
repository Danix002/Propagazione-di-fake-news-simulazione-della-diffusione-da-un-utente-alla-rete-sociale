export {default} from "./1228c1f9cc0df19c@636.js";
