## Italy Demonyms Map

[https://russbiggs.github.io/italydemonyms](https://russbiggs.github.io/italydemonyms) 

A d3.js (v3) based map of Italy's 8,047 comuni and their respective demonym scraped from wikipedia.  The python scripts in the repo were used to scrape the data from wikipedia and transform into topojson for display in the web map.  Since wikipedia frequently changes the scraping may become out-of-date and not match the scrape as I used it.